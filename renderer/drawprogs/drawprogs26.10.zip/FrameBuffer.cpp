/*
===========================================================================

Doom 3 GPL Source Code
Copyright (C) 1999-2011 id Software LLC, a ZeniMax Media company.

This file is part of the Doom 3 GPL Source Code ("Doom 3 Source Code").

Doom 3 Source Code is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Doom 3 Source Code is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Doom 3 Source Code.  If not, see <http://www.gnu.org/licenses/>.

In addition, the Doom 3 Source Code is also subject to certain additional terms. You should have received a copy of these additional terms immediately following the terms and conditions of the GNU General Public License which accompanied the Doom 3 Source Code.  If not, please request a copy in writing from id Software at the address below.

If you have questions concerning this license or the applicable additional terms, you may contact in writing id Software LLC, c/o ZeniMax Media Inc., Suite 120, Rockville, Maryland 20850 USA.

===========================================================================
*/

#include "FrameBuffer.h"

nmFrameBuffer::nmFrameBuffer(bool MultAtachament, int Atachaments)
{
	frameBuffer = GLuint(0);
	ColorTexture = 0;

	this->MultAtachament = MultAtachament;

	//Maximum of 5 Color Attachament
	assert(Atachaments <= 5);
	this->Atachaments = Atachaments;

}

nmFrameBuffer::~nmFrameBuffer()
{
	if (ColorTextures[0] != 0)
		glDeleteTextures(Atachaments, ColorTextures);
	
	if (ColorTexture != 0)
		glDeleteTextures(1, &ColorTexture);

	if (frameBuffer != 0)
		glDeleteFramebuffers(1, &frameBuffer);

	MultAtachament = false;
}

bool	nmFrameBuffer::GenerateFB(int Width, int Height, bool HasDepth, unsigned int ColorAttachament)
{
	//Render FreameBuffer
	glGenFramebuffers(1, &frameBuffer);

	glBindFramebuffer(GL_FRAMEBUFFER, frameBuffer);

	//the Color Textures
	if (MultAtachament)
	{
		glGenTextures(Atachaments, ColorTextures);

		for (unsigned int i = 0; i < Atachaments; i++)
		{
			glBindTexture(GL_TEXTURE_2D, ColorTextures[i]);
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB16F, Width, Height, 0, GL_RGB, GL_FLOAT, NULL);

			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

			glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT0 + i, GL_TEXTURE_2D, ColorTextures[i], 0);
		}

		GLenum DrawBuffers[] = { 
			GL_COLOR_ATTACHMENT0,
			GL_COLOR_ATTACHMENT1,
			GL_COLOR_ATTACHMENT2,
			GL_COLOR_ATTACHMENT3,
			GL_COLOR_ATTACHMENT5,
		};

		GLuint DBlength = sizeof(DrawBuffers[0]) / sizeof(DrawBuffers);
		glDrawBuffers(DBlength, DrawBuffers);
	}
	else
	{
		glBindTexture(GL_TEXTURE_2D, ColorTexture);

#if 1
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB16, Width, Height, 0, GL_RGB16, GL_UNSIGNED_BYTE, NULL);
#else
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB16F, Width, Height, 0, GL_RGB16F, GL_UNSIGNED_BYTE, NULL);
#endif
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

		glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0 + ColorAttachament, GL_TEXTURE_2D, ColorTexture, 0);

		// Set the list of draw buffers.
		GLenum DrawBuffers[1] = { GL_COLOR_ATTACHMENT0 + ColorAttachament };
		glDrawBuffers(1, DrawBuffers); // "1" is the size of DrawBuffers
	}

	GLenum Status = glCheckFramebufferStatus(GL_FRAMEBUFFER);

	if (Status != GL_FRAMEBUFFER_COMPLETE) 
	{
		common->Warning("FRAMEBUFFER error, status: 0x%x\n", Status);
		return false;
	}

	return true;
}

nmFrameBuffersGlobal GlobalFrameBuffers;

nmFrameBuffersGlobal::nmFrameBuffersGlobal()
{

	QuadScreenSet = false;

	//Create a Buffer whit 3 colors Attachaments
	RenderBuffer = new nmFrameBuffer(true, 3);
}

nmFrameBuffersGlobal::~nmFrameBuffersGlobal()
{
	delete RenderBuffer;
}

void	nmFrameBuffersGlobal::init()
{
	this->CreateScreen();// Create a quad screen

	//the Render Buffer that Stores the Render Color, Render Normal, Depth, and Render Specular
	RenderBuffer->GenerateFB(glConfig.vidWidth, glConfig.vidHeight);
}

void	nmFrameBuffersGlobal::CreateScreen()
{

	static const GLfloat g_quad_vertex_buffer_data[] = {
		-0.5f, -0.5f, 0.0f,
		0.5f, -0.5f, 0.0f,
		-0.5f, 0.5f, 0.0f,
		-0.5f, 0.5f, 0.0f,
		0.5f, -0.5f, 0.0f,
		0.5f, 0.5f, 0.0f,
	};

	static const GLfloat g_quad_Color_buffer_data[] = {
		1.0f, 0.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 0.0f, 1.0f,
		0.5f, 0.5f, 0.0f,
		0.5f, 0.0f, 0.5f,
		0.0f, 0.5f, 0.5f,
	};

	static const GLfloat g_quad_texcoord_buffer_data[] = {
		0.0f, 0.0f, 
		1.0f, 0.0f, 
		1.0f, 1.0f,
		0.0f, 0.0f, 
		1.0f, 1.0f, 
		0.0f, 1.0f,
	};

	glGenBuffers(1, &ScreenQuadVertBuff);
	glBindBuffer(GL_ARRAY_BUFFER, ScreenQuadVertBuff);
	glBufferData(GL_ARRAY_BUFFER, sizeof(g_quad_vertex_buffer_data), g_quad_vertex_buffer_data, GL_STATIC_DRAW);

	glGenBuffers(1, &ScreenQuadTexcBuff);
	glBindBuffer(GL_ARRAY_BUFFER, ScreenQuadTexcBuff);
	glBufferData(GL_ARRAY_BUFFER, sizeof(g_quad_texcoord_buffer_data), g_quad_texcoord_buffer_data, GL_STATIC_DRAW);

	glGenBuffers(1, &ScreenQuadColoBuff);
	glBindBuffer(GL_ARRAY_BUFFER, ScreenQuadColoBuff);
	glBufferData(GL_ARRAY_BUFFER, sizeof(g_quad_Color_buffer_data), g_quad_Color_buffer_data, GL_STATIC_DRAW);

	QuadScreenSet = true;
};
