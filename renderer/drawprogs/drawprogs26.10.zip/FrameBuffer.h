/*
===========================================================================

Doom 3 GPL Source Code
Copyright (C) 1999-2011 id Software LLC, a ZeniMax Media company.

This file is part of the Doom 3 GPL Source Code ("Doom 3 Source Code").

Doom 3 Source Code is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Doom 3 Source Code is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Doom 3 Source Code.  If not, see <http://www.gnu.org/licenses/>.

In addition, the Doom 3 Source Code is also subject to certain additional terms. You should have received a copy of these additional terms immediately following the terms and conditions of the GNU General Public License which accompanied the Doom 3 Source Code.  If not, please request a copy in writing from id Software at the address below.

If you have questions concerning this license or the applicable additional terms, you may contact in writing id Software LLC, c/o ZeniMax Media Inc., Suite 120, Rockville, Maryland 20850 USA.

===========================================================================
*/

#ifndef FRAMEBUFFER_H
#define FRAMEBUFFER_H

#include "renderer/tr_local.h"	
#define MULTIPASSES 1

class nmFrameBuffer
{
public:
	nmFrameBuffer(bool MultAtachament, int Atachaments);
	~nmFrameBuffer();

	enum
	{
		TO_UNDEF = 0,
		TO_RENDER,
		TO_DRAW

	};

	static enum SCREEN_TEXTURE_TYPE
	{
		SCREEN_TEXTURE_ATTACHAMENT_0,
		SCREEN_TEXTURE_ATTACHAMENT_1,
		SCREEN_TEXTURE_ATTACHAMENT_2,
		SCREEN_TEXTURE_ATTACHAMENT_3,
		SCREEN_TEXTURE_ATTACHAMENT_4
	};

	//Create The Buffer
	bool			GenerateFB(int Width, int Height, bool HasDepth = false, unsigned int ColorAttachament = 0);

	//Bind The Buffer
	void			Bind() { glBindFramebuffer(GL_FRAMEBUFFER, frameBuffer); };
	void			BindForWriting() { glBindFramebuffer(GL_DRAW_FRAMEBUFFER, frameBuffer); };
	void			BindForReading() { glBindFramebuffer(GL_READ_FRAMEBUFFER, frameBuffer); };
	GLuint			GetFramebuffer() { return this->frameBuffer; };

	// back to default
	static void		BindDefalt() { glBindFramebuffer(GL_FRAMEBUFFER, 0); }

	GLuint	GetRenderTextures(SCREEN_TEXTURE_TYPE type)
	{
		return ColorTextures[type];
	}

	GLuint	GetRenderTexture(void)
	{
		return ColorTexture;
	}

private:
	
	bool MultAtachament;
	unsigned int Atachaments;

	//Frame Buffers
	GLuint frameBuffer;

	//Textures Buffers
#if 0
	idList<GLuint*>ColorTextures;
#else
	GLuint ColorTextures[5];
#endif

	GLuint ColorTexture;
};


class nmFrameBuffersGlobal
{
public:
	nmFrameBuffersGlobal();
	~nmFrameBuffersGlobal();

	void				init();
	void				CreateScreen();
	nmFrameBuffer*		RenderBuffer;

	void				DrawScreenRect()
	{
		if (!QuadScreenSet)
			return;

		//Position
		glEnableVertexAttribArray(0);
		glBindBuffer(GL_ARRAY_BUFFER, ScreenQuadVertBuff);
		glVertexAttribPointer( 0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

		//TexCoord
		glEnableVertexAttribArray(1);
		glBindBuffer(GL_ARRAY_BUFFER, ScreenQuadTexcBuff);
		glVertexAttribPointer( 1, 2, GL_FLOAT,GL_FALSE, 0, (void*)0);

		//Vertex Color
		glEnableVertexAttribArray(1);
		glBindBuffer(GL_ARRAY_BUFFER, ScreenQuadColoBuff);
		glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

		glDrawArrays(GL_TRIANGLES, 0, 6);
		glDisableVertexAttribArray(0);
		glDisableVertexAttribArray(1);
		glDisableVertexAttribArray(2);
	};

private:
	bool QuadScreenSet;

	GLuint ScreenQuadVertBuff;
	GLuint ScreenQuadTexcBuff;
	GLuint ScreenQuadColoBuff;
};

extern nmFrameBuffersGlobal GlobalFrameBuffers;

#endif /* !FRAMEBUFFER_H */
